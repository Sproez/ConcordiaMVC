﻿//using System.ComponentModel.DataAnnotations;
//using ConcordiaLib.Domain;
//using ConcordiaLib.Enum;

//namespace ConcordiaMVC.Dto;


//public record CardDto
//    (
//        [Required]
//        string Id,
//        [Required]
//        string Title,
//        [Required]
//        string Description,
//        DateTime? DueBy,
//        [Required]
//        Priority Priority,
//        [Required]
//        string Status 

//    )
//{

//       public string id;
//       public string title; 
//       public string Description;  
//       public DateTime? DueBy;
//       public Priority Priority;
//       public string Status;   

//}

