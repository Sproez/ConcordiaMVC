﻿namespace ConcordiaWebApi.Abstract
{
    public interface Interface
    {
    }
}
