﻿using ConcordiaOrchestrator;

await Orchestrator.Sync();
Console.WriteLine("DONE");